#include <stdio.h>
#include <string.h>
#include "funciones.h"

char nombresIng[10][20], nombres[10][20];
int contI = 0, contP = 0, stock[10], receta[10][10];
float precio[10], tiempoPrep[10];

void limpiarBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
    }
}

void leerCadena(char cadena[]) {
    int valido, i;

    do {
        valido = 0;
        fgets(cadena, 20, stdin);
        cadena[strcspn(cadena, "\n")] = '\0';
        for (i = 0; cadena[i] != '\0'; i++) {
            if (cadena[i] != ' ') {
                valido = 1;
            }
        }
        if (valido == 0) {
            printf("Nombre invalido. Intente nuevamente: ");
        }
    } while (valido == 0);
}

int validarRangoEntero(int a, int b) {
    int val, num = 0, extra;

    do {
        val = scanf("%d", &num);
        extra = getchar();

        if (extra != '\n' && extra != EOF) {
            limpiarBuffer();
        }

        if (val != 1 || num < a || num > b || extra != '\n') {
            printf("Ingreso invalido. Intente nuevamente: ");
        }

    } while (val != 1 || num < a || num > b || extra != '\n');

    return num;
}

int validarPositivoEntero() {
    int val, num = 0, extra;

    do {
        val = scanf("%d", &num);
        extra = getchar();

        if (extra != '\n' && extra != EOF) {
            limpiarBuffer();
        }

        if (val != 1 || num <= 0 || extra != '\n') {
            printf("Ingreso invalido. Intente nuevamente: ");
        }

    } while (val != 1 || num <= 0 || extra != '\n');

    return num;
}

float validarPositivoFloat() {
    int val, extra;
    float num = 0;

    do {
        val = scanf("%f", &num);
        extra = getchar();

        if (extra != '\n' && extra != EOF) {
            limpiarBuffer();
        }

        if (val != 1 || !(num > 0) || extra != '\n') {
            printf("Ingreso invalido. Intente nuevamente: ");
        }

    } while (val != 1 || !(num > 0) || extra != '\n');

    return num;
}

void registrarIngrediente() {
    int repetido;
    if (contI >= 10) {
        printf("Maximo de Ingredientes alcanzados.\n");
        return;
    }
    do {
        repetido = 0;
        printf("Ingrese el nombre del Ingrediente %d: ", contI + 1);
        leerCadena(nombresIng[contI]);
        for (int i = 0; i < contI; i++) {
            if (strcmp(nombresIng[contI], nombresIng[i]) == 0) {
                repetido = 1;
            }
        }
        if (repetido == 1) {
            printf("Este ingrediente ya existe. Intente con otro nombre.\n");
        }
    } while (repetido == 1);

    printf("Ingrese la Cantidad en inventario (unidades): ");
    stock[contI] = validarPositivoEntero();

    contI++;

    printf("Ingrediente registrado correctamente.\n");
}

void registrarProducto() {
    int repetido;
    if (contI == 0) {
        printf("Primero registre ingredientes.\n");
        return;
    }
    if (contP >= 10) {
        printf("Maximo de Productos alcanzados.\n");
        return;
    }
    do {
        repetido = 0;
        printf("Ingrese el nombre del Producto %d: ", contP + 1);
        leerCadena(nombres[contP]);
        for (int i = 0; i < contP; i++) {
            if (strcmp(nombres[contP], nombres[i]) == 0) {
                repetido = 1;
            }
        }
        if (repetido == 1) {
            printf("Este producto ya existe. Intente con otro nombre.\n");
        }
    } while (repetido == 1);

    printf("Ingrese el Precio: ");
    precio[contP] = validarPositivoFloat();

    printf("Ingrese el Tiempo de Preparacion (minutos): ");
    tiempoPrep[contP] = validarPositivoFloat();

    for (int i = 0; i < contI; i++) {
        printf("Cantidad de %s por unidad (0 si no lleva): ", nombresIng[i]);
        receta[contP][i] = validarRangoEntero(0, 1000);
    }

    contP++;

    printf("Producto registrado correctamente.\n");
}

void mostrarProductos() {
    if (contP == 0) {
        printf("No hay productos registrados.\n");
        return;
    }

    printf("N\t\tNombre\t\t\tPrecio\t\tTiempo (min)\t\tReceta\n");
    for(int i = 0; i < contP ; i++) {
        printf("%d\t\t%s\t\t\t%.2f\t\t%.2f\t\t\t",i+1,nombres[i],precio[i],tiempoPrep[i]);
        for (int j = 0; j < contI; j++) {
            if (receta[i][j] > 0) {
                printf("%s x%d  ", nombresIng[j], receta[i][j]);
            }
        }
        printf("\n");
    }
}

void editarProducto() {
    char buscar[20], nuevoNombre[20];
    int opcion, seguir, repetido;
    if (contP == 0) {
        printf("No hay productos registrados.\n");
        return;
    }
    printf("Ingrese el nombre del Producto que desea editar: ");
    leerCadena(buscar);
    for(int i = 0; i < contP; i++) {
        if(strcmp(buscar, nombres[i]) == 0) {
            printf(">> Producto encontrado\n");
            do {

                printf("¿Que desea editar?\n");
                printf("1. Nombre\n");
                printf("2. Precio\n");
                printf("3. Tiempo de Preparacion\n");
                printf("4. Receta\n");
                printf(">> ");
                opcion = validarRangoEntero(1, 4);

                switch (opcion) {
                    case 1:
                        do {
                            repetido = 0;
                            printf("Ingrese el nuevo nombre: ");
                            leerCadena(nuevoNombre);
                            for (int j = 0; j < contP; j++) {
                                if (j != i && strcmp(nuevoNombre, nombres[j]) == 0) {
                                    repetido = 1;
                                }
                            }
                            if (repetido == 1) {
                                printf("Este producto ya existe. Intente nuevamente.\n");
                            }
                        } while (repetido == 1);
                        strcpy(nombres[i], nuevoNombre);
                        break;
                    case 2:
                        printf("Ingrese el nuevo Precio: ");
                        precio[i] = validarPositivoFloat();
                        break;
                    case 3:
                        printf("Ingrese el nuevo Tiempo de Preparacion: ");
                        tiempoPrep[i] = validarPositivoFloat();
                        break;
                    case 4:
                        for (int j = 0; j < contI; j++) {
                            printf("Nueva cantidad de %s por unidad: ", nombresIng[j]);
                            receta[i][j] = validarRangoEntero(0, 1000);
                        }
                        break;
                }

                printf("Desea editar otra opcion? 1. Si / 2. No\n");
                printf(">> ");
                seguir = validarRangoEntero(1,2);
            } while(seguir == 1);
            return;
        }
    }
    printf("Producto no encontrado.\n");
}

void eliminarProducto(){
    char buscar[20];
    if (contP == 0) {
        printf("No existen productos registrados\n");
        return;
    }
    printf("Ingrese el nombre del Producto que desea borrar: ");
    leerCadena(buscar);
    for (int i = 0; i < contP; i++) {
        if(strcmp(buscar, nombres[i]) == 0) {

            for (int j = i; j < contP - 1; j++) {
                strcpy(nombres[j], nombres[j + 1]);
                precio[j] = precio[j + 1];
                tiempoPrep[j] = tiempoPrep[j + 1];
                for (int k = 0; k < contI; k++) {
                    receta[j][k] = receta[j + 1][k];
                }
            }

            contP--;
            printf("Producto eliminado correctamente.\n");
            return;

        }
    }
    printf("Producto no encontrado.\n");
}

void evaluarPedido() {
    int necesarios[10] = {0}, pos, cant, seguir, ingOk = 1;
    float tiempoTotal = 0, total = 0, tiempoDisp;
    if (contP == 0) {
        printf("No existen productos registrados\n");
        return;
    }
    do {
        printf("Productos disponibles:\n");
        for (int i = 0; i < contP; i++) {
            printf("%d. %s\n", i + 1, nombres[i]);
        }
        printf("Seleccione el producto: ");
        pos = validarRangoEntero(1, contP) - 1;
        printf("Ingrese la cantidad: ");
        cant = validarPositivoEntero();

        for (int j = 0; j < contI; j++) {
            necesarios[j] += cant * receta[pos][j];
        }
        tiempoTotal += cant * tiempoPrep[pos];
        total += cant * precio[pos];

        printf("Desea agregar otro producto al pedido? 1. Si / 2. No\n");
        printf(">> ");
        seguir = validarRangoEntero(1,2);
    } while (seguir == 1);

    printf("Ingrese el Tiempo disponible para el pedido (minutos): ");
    tiempoDisp = validarPositivoFloat();

    printf("--Pedido--\n");
    printf("Ingrediente\t\tNecesario\t\tDisponible\n");
    for (int j = 0; j < contI; j++) {
        printf("%s\t\t\t%d\t\t\t%d\n", nombresIng[j], necesarios[j], stock[j]);
        if (necesarios[j] > stock[j]) {
            ingOk = 0;
        }
    }
    printf("Tiempo requerido: %.2f min / Tiempo disponible: %.2f min\n", tiempoTotal, tiempoDisp);
    printf("Total a cobrar: %.2f\n", total);

    if (tiempoTotal <= tiempoDisp && ingOk == 1) {
        printf("Tiempo suficiente e ingredientes suficientes. Pedido viable.\n");
    } else if (tiempoTotal <= tiempoDisp && ingOk == 0) {
        printf("Tiempo suficiente e ingredientes insuficientes. Pedido no viable por ingredientes.\n");
    } else if (tiempoTotal > tiempoDisp && ingOk == 1) {
        printf("Tiempo insuficiente e ingredientes suficientes. Pedido no viable por tiempo.\n");
    } else {
        printf("Tiempo insuficiente e ingredientes insuficientes. Pedido no viable por tiempo e ingredientes.\n");
    }
}

void actualizarInventario() {
    int opcion, pos, cant;
    if (contI == 0) {
        printf("No hay ingredientes registrados.\n");
        return;
    }
    printf("1. Reabastecer ingrediente\n");
    printf("2. Registrar consumo o perdida\n");
    printf(">> ");
    opcion = validarRangoEntero(1, 2);
    for (int i = 0; i < contI; i++) {
        printf("%d. %s (%d)\n", i + 1, nombresIng[i], stock[i]);
    }
    printf("Seleccione el ingrediente: ");
    pos = validarRangoEntero(1, contI) - 1;
    printf("Ingrese la cantidad: ");
    if (opcion == 1) {
        stock[pos] += validarPositivoEntero();
    } else {
        cant = validarRangoEntero(1, stock[pos] > 0 ? stock[pos] : 1);
        if (cant > stock[pos]) {
            printf("No hay stock suficiente.\n");
            return;
        }
        stock[pos] -= cant;
    }
    printf("Inventario actualizado. Stock de %s: %d\n", nombresIng[pos], stock[pos]);
}
