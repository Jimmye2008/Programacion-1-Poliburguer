#include <stdio.h>
#include "funciones.h"

int main() {

    int opc, opc2;

    printf("Bienvenid@ a Poliburguer\n");

    do{

        printf("Seleccione una opcion:\n");
        printf("1. Registrar Ingrediente\n");
        printf("2. Registrar Producto\n");
        printf("3. Mostrar Productos\n");
        printf("4. Editar Producto\n");
        printf("5. Eliminar Producto\n");
        printf("6. Evaluar Pedido\n");
        printf("7. Actualizar Inventario\n");
        printf("8. Salir\n");
        printf(">> ");
        opc = validarRangoEntero(1,8);

        switch (opc) {
            case 1:
                registrarIngrediente();
                break;
            case 2:
                registrarProducto();
                break;
            case 3:
                mostrarProductos();
                break;
            case 4:
                editarProducto();
                break;
            case 5:
                eliminarProducto();
                break;
            case 6:
                evaluarPedido();
                break;
            case 7:
                actualizarInventario();
                break;
            case 8:
                return 0;
        }
        printf("Desea seleccionar otra opcion? 1. Si / 2. No\n");
        printf(">> ");
        opc2 = validarRangoEntero(1,2);
    } while(opc2 == 1);

    return 0;
}
