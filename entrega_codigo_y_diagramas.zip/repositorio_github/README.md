# Programación 1: Poliburguer

Programa en C para controlar el inventario de ingredientes y evaluar si un pedido es viable en la hamburguesería Poliburguer.

## Carpetas
- Alternativa_2_seleccionada: código usado en el informe. Usa estructuras y punteros.
- Alternativa_1: otra alternativa que se comparó, con arreglos paralelos.

## Compilar y ejecutar
gcc main.c funciones.c -o poliburguer
./poliburguer

## Opciones del menú
1. Registrar ingredientes e inventario
2. Registrar productos del menú
3. Información registrada de producto
4. Editar información
5. Eliminar producto
6. Evaluar pedido
7. Actualizar inventario
8. Consultar existencias finales
9. Salir
